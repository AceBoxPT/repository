![xStream logo](https://github.com/StoneOffStones/plugin.video.xstream/blob/wiki/graphics/website/logo/logo_512.png?raw=true)


## Willkommen bei xStream für Kodi!

Bei xStream handelt es sich um ein Video Addon für die Media-Center-Software Kodi. Es ermöglicht über eine intuitive und optisch ansprechende Benutzeroberfläche das streamen von Serien und Filme aus unterschiedlichsten Streaming-Quellen.
***

[![Join the chat at https://gitter.im/xStream-Kodi/Public](https://badges.gitter.im/xStream-Kodi/Public.svg)](https://gitter.im/xStream-Kodi/Public?utm_source=badge&utm_medium=badge&utm_campaign=pr-badge&utm_content=badge)

### | [Homepage](https://xstream-kodi.github.io) | [Wiki](https://github.com/xStream-Kodi/plugin.video.xstream/wiki) | [Forum](http://xstream-addon.square7.ch) | [Site-Plugin Wunschliste] (https://docs.google.com/spreadsheets/d/1b_9C6BONlpWcugMgocFbKxe7nFp99HfvVUJznxTzT4I/edit?usp=sharing) | [GitHub](https://github.com/xStream-Kodi/plugin.video.xstream) |

