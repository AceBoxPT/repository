import xbmcaddon

MainBase = 'https://www.dropbox.com/s/avs39he4k706vaw/MENU.txt?dl=1'
addon = xbmcaddon.Addon('plugin.video.AniPT')